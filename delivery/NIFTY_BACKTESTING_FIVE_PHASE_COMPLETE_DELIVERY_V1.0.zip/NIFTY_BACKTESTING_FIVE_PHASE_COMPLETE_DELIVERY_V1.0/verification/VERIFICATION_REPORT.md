# NIFTY Backtesting Five-Phase Delivery — Verification Report

**Delivery version:** 1.0  
**Verification date:** 2 August 2026  
**Overall status:** PASS for the isolated reference implementation and sequential overlay packaging. Target-repository and real-data acceptance remains pending.

## 1. Verification scope

This report verifies that the supplied code and phase bundles form a coherent, installable reference implementation. It does not claim that the code has already been merged into the production Novius2 repository, migrated against the live database or qualified against the complete historical dataset.

## 2. Reference environment results

| Verification area | Result | Evidence |
|---|---|---|
| Python source import/compilation through test execution | PASS | Complete cumulative test suite |
| Integrated automated tests | PASS — 22 tests | `FINAL_VERIFICATION_LOG.txt` |
| Phase 1 smoke | PASS | Effective-dated session/expiry and qualification baseline |
| Phase 2 smoke | PASS | Net-target solver and deterministic event replay |
| Phase 3 smoke | PASS | Deterministic run identity and six planned shards |
| Phase 4 smoke | PASS | Opportunity labels, out-of-fold predictions and Brier calculation |
| Phase 5 smoke | PASS | Actual-premium option replay, IV inversion, parity and pack validation |
| Phase bundle manifests | PASS | 40, 42, 32, 28 and 35 files respectively |
| Sequential phase overlays | PASS | Applied in order to a clean mock Git repository |
| Cumulative suite after overlays | PASS — 22 tests | `FINAL_VERIFICATION_LOG.txt` |
| Word roadmap rendering | PASS | 23 pages visually inspected; no clipping/blank-page defects retained |

## 3. Recorded smoke values

These values are deterministic synthetic/reference evidence. They are not trading-performance claims.

| Phase | Recorded reference output |
|---|---|
| 1 | F&O session count after the configured 3 August 2026 rule: 385 bars; example expiry: 4 August 2026 |
| 2 | Minimum-tick target example: ₹501.55 exit; 8 synthetic trades; synthetic net P&L −₹1,144.63 |
| 3 | Deterministic run ID `run_351a4997287fa23e4fd1c6ad65e6f36e`; 6 shards |
| 4 | 699 opportunity labels; 400 out-of-fold samples; Brier score 0.0427516809431703 |
| 5 | Synthetic option net P&L ₹560.69; recovered IV approximately 0.18; parity differences 0; 3 research-pack files verified |

## 4. Phase-by-phase reference tests

### Phase 1

Validated in the reference code:

- canonical bar/signal contracts;
- effective-dated market sessions and expiry rules;
- source manifests/checksums;
- CSV schema/OHLC/duplicate qualification paths; and
- point-in-time adapter interfaces.

Still required in the target environment:

- run against the full stock/index/VIX file estate;
- generate saved PASS/WARN/FAIL reports per real source file;
- reconcile overlapping sources; and
- validate the real database role is read-only for qualification.

### Phase 2

Validated in the reference code:

- Decimal component-level equity cost calculation;
- minimum valid tick solving;
- chronological indicators and prefix-parity checks;
- strategy plug-in interface;
- next-bar event simulation;
- stop/target ambiguity policy; and
- finite cash/net-liquidation accounting.

Still required in the target environment:

- reconcile against current broker contract notes and effective dates;
- implement or retire retained Go/TypeScript fee calculations through golden vectors; and
- reconcile reference trades with selected legacy strategy outputs.

### Phase 3

Validated in the reference code:

- deterministic run and shard identities;
- file and PostgreSQL-oriented ledger interfaces;
- shard leases/checkpoint state;
- restart/idempotency test paths;
- metrics; and
- validation-gated publication design.

Still required in the target environment:

- kill/restart a real multi-year job;
- test concurrent workers against a disposable PostgreSQL copy;
- prove completed shards are not recomputed; and
- benchmark real query and storage load.

### Phase 4

Validated in the reference code:

- executable opportunity labels;
- leakage guards;
- simple candidate pattern discovery;
- chronological walk-forward splits; and
- out-of-fold probability calibration/evidence.

Still required in the target environment:

- reserve and lock the final untouched holdout;
- apply purge/embargo based on each real label horizon;
- retain every trial in the real experiment ledger; and
- perform stability/multiple-testing analysis over full history.

### Phase 5

Validated in the reference code:

- point-in-time option-contract objects;
- buying-only premium replay with lot sizing and transaction costs;
- Black–Scholes Greeks and implied-volatility diagnostics;
- batch/incremental parity oracle; and
- safe, checksummed research ZIP packs and analyst response schema.

Still required in the target environment:

- qualify/backfill actual historical option contracts and premium bars;
- enforce live source-freshness gates against current chain/OI/Greeks tables;
- confirm option data licensing/use; and
- prove parity against the real SmartAPI event stream.

## 5. Packaging verification

Before final issue, every delivery ZIP is checked for:

- successful ZIP CRC/integrity test;
- no absolute archive paths;
- no `..` path traversal entries;
- presence of `CODEX_PROMPT.md` in every phase;
- presence of `LOW_CONTEXT_TASK.md` and direct runners in every phase;
- phase manifest consistency; and
- SHA-256 listing in `SHA256SUMS.txt`.

The final packaging log and manifest are supplied with the delivery.

## 6. Safety and production boundary

The reference implementation contains no broker-order placement. It does not authorise or automate production database migrations. The SmartAPI collector remains unchanged. Production migration, paper/shadow deployment and any later constrained-live operation require separate review, test evidence, risk limits, reconciliation and approval.

## 7. Acceptance classification

**Reference implementation:** Complete.  
**Phase packaging and agent handoff:** Complete.  
**Actual target-repository integration:** Pending execution by the phase agents/developers.  
**Real PostgreSQL and full historical-data acceptance:** Pending.  
**Live trading authority:** Out of scope.

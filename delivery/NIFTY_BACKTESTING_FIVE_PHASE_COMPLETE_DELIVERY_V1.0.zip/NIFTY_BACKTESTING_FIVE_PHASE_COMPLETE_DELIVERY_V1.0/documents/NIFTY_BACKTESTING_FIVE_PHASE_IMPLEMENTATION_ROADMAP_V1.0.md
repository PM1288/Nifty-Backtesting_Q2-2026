# NIFTY Strategy Research and Backtesting Platform
## Five-Phase Implementation Roadmap and Code Delivery Plan

**Document version:** 1.0  
**Issue date:** 2 August 2026  
**Status:** Reference implementation complete; target-repository integration pending  
**Primary scope:** NIFTY 50 cash-equity backtesting, intraday-to-swing evaluation, reverse opportunity discovery, buying-only option research, historical/online parity and analyst research packs

## 1. Programme objective

The programme converts the accumulated historical scripts, PostgreSQL datasets and current SmartAPI collector into one reusable platform. A strategy author should supply only the strategy logic and parameters. The platform supplies point-in-time data, features, transaction economics, execution simulation, capital accounting, restartability, validation, probability calibration, comparison and evidence logging.

The implementation is deliberately incremental. The SmartAPI collector remains the live-ingestion boundary; existing PostgreSQL facts remain available; legacy Go, Python and TypeScript components are adapted rather than deleted before reconciliation.

## 2. Why five phases

The sequence prevents attractive but invalid strategy results from being built on uncertain data, incomplete charges, look-ahead, unresumable jobs or uncalibrated scores. Each phase has a release gate. A later phase may not create a competing calendar, cost formula, feature calculation, fill rule or run ledger.

```mermaid
flowchart LR
    P1[Phase 1
Trusted data and time] --> P2[Phase 2
Economics and simulator]
    P2 --> P3[Phase 3
Resumable ten-year replay]
    P3 --> P4[Phase 4
Discovery and probability]
    P4 --> P5[Phase 5
Options, parity and packs]
    P5 --> NEXT[Later programme
Paper, shadow and controlled live]
```

## 3. Current estate used by the plan

| Estate | Confirmed basis | Treatment |
|---|---|---|
| PostgreSQL `tradingdb` | 208 tables/partitions, daily, minute, options, FII/DII, features and backtest result families documented in the supplied audit | Reuse facts; add bounded `catalog`, `research` and `simulation` schemas |
| Historical stock minutes | 100 files, approximately 4.30 GiB at `/home/novius2/data/nifty-50-minute-data/aaditya555` | Qualify before admission; convert accepted data to canonical analytical storage later |
| Historical index/sector/VIX | 680 files, approximately 3.90 GiB at `/home/novius2/data/nifty-50-minute-data/debashis74017` | Qualify and align to stock bars and trading calendar |
| FII/DII workbook | Download/checksum record available at `/home/novius2/data/fii-dii-and-nifty-historical-study-july-2023` | Profile internal sheets and availability before feature use |
| Legacy code | Go backtest runners, Python worker, SQL marts, strategy registry and TypeScript routes | Wrap, reconcile, then retire duplicates gradually |
| Live collector | SmartAPI to PostgreSQL | Unchanged in these five phases |

## 4. Phase summary

| Phase | Outcome | Principal release gate | Relative effort |
|---:|---|---|---:|
| 1 | Trusted data/time/contracts and qualification | No unqualified source enters research | 20% |
| 2 | Exact costs, net target solver, strategy SDK and event simulator | Temporal and financial golden tests pass | 25% |
| 3 | Resumable ten-year replay and validation-gated results | Kill/restart and publication controls pass | 20% |
| 4 | Reverse discovery and calibrated probability | Leakage-controlled out-of-fold evidence exists | 20% |
| 5 | Buying-only options, parity and analyst packs | Actual-premium, freshness, parity and pack gates pass | 15% |

Percentages are relative implementation effort for sequencing and staffing; they are not calendar commitments.

## 5. Detailed phase plans

### 5.1 Phase 1 — Data Foundation, Point-in-Time Contracts and Qualification

**Objective:** Create the trusted data/time boundary required before any strategy result can be believed.

**Dependency:** None. This is the mandatory first phase.

**Features delivered**

- Canonical, timezone-aware market-bar and feature/signal contracts.
- Effective-dated NSE cash and derivatives session profiles.
- Effective-dated Tuesday weekly/monthly expiry rules with holiday adjustment.
- Immutable source-file checksums and dataset manifests.
- Streaming historical CSV qualification: schema, timestamps, OHLC, duplicates, ordering, sessions and missing minutes.
- Read-only PostgreSQL coverage inspection and point-in-time NIFTY universe adapter.
- Non-destructive catalog schemas for source, quality, calendar, instrument aliases and universe snapshots.
- Language-neutral JSON Schemas and session/expiry golden vectors.

**Release criteria**

- All Phase 1 tests and smoke test pass from a clean virtual environment.
- Every admitted source file has SHA-256, schema profile, timestamp range and explicit PASS/WARN/FAIL status.
- Conflicting duplicate bars and invalid OHLC rows force quarantine.
- A historical query can resolve the universe as of a supplied date rather than current constituents.
- NSE CM resolves 375 one-minute bars for 09:15–15:30; configured F&O session changes resolve by effective date.
- No production database write occurs during qualification; migration execution is separately authorised.

**Delivery bundle:** `NIFTY_BACKTEST_PHASE_01_*.zip`


### 5.2 Phase 2 — Exact Economics, Feature Registry, Strategy SDK and Event Simulator

**Objective:** Create one financially and temporally correct execution engine reusable by all equity strategies.

**Dependency:** Phase 1 must be merged and its release gate must pass.

**Features delivered**

- Decimal, effective-dated fee schedules with component-level rounding.
- Brokerage, STT, exchange, SEBI, IPFT, stamp, GST, DP, slippage and impact accounting.
- Minimum valid tick solver for ₹500/₹1,000 or any configured net target.
- Per-symbol chronological RSI, Williams %R, SMA, MACD and session VWAP.
- Prefix-parity test that detects future-data dependency in batch features.
- Versioned strategy manifests and plug-in interface; strategy emits intents, not fills.
- Finite-cash, next-bar-open, long-only event simulator with target/stop/time exits.
- Conservative/optimistic/rejected intrabar ambiguity policies.
- Gross and net-liquidation equity, skipped-signal evidence and open-position state.
- Cross-language golden fee vectors.

**Release criteria**

- Every golden fee vector matches in Python and any retained Go/TypeScript implementation.
- The returned target is the first exchange-valid tick meeting the configured net P&L; the prior tick fails.
- A signal generated at a completed bar cannot enter on that same bar.
- Same-bar stop/target conflicts are counted and follow the declared path policy.
- Cash never becomes negative and ticket size includes entry charges.
- Open-position reporting includes estimated exit costs in net liquidation value.
- The reference strategy runs end to end on deterministic synthetic bars and produces reproducible checksums.

**Delivery bundle:** `NIFTY_BACKTEST_PHASE_02_*.zip`


### 5.3 Phase 3 — Resumable Historical Backtesting, Experiment Ledger and Results

**Objective:** Turn the correct simulator into an operational ten-year backtesting service that can stop, resume, validate and publish safely.

**Dependency:** Phases 1 and 2 must be merged and stable.

**Features delivered**

- Immutable run identity over strategy, data, universe, features, costs, execution model, scope, code and seed.
- Deterministic date-block × symbol-bucket shard planner.
- Durable leases, heartbeats, attempts, cursors, output checksums and restart.
- Local file ledger for tests/recovery drills and PostgreSQL `SKIP LOCKED` production ledger.
- Idempotent signal, trade, skipped-signal and equity persistence.
- Net P&L, costs, win rate, profit factor, drawdown, Sharpe and ambiguity metrics.
- Atomic validation-gated publication; failed or incomplete runs cannot become current.
- Compatibility period in which legacy `nse_app.backtest_*` tables remain readable but are no longer the source of new truth.

**Release criteria**

- Killing a worker after a durable checkpoint reruns only the uncompleted shard.
- Expired leases can be reclaimed; completed shards are never silently recomputed.
- The same run specification produces the same run/shard IDs and checksummed outputs.
- All accounting identities reconcile: net P&L = gross P&L − total cost; gross equity = cash + market value.
- A run with any incomplete shard or failed mandatory validation cannot publish.
- Full-scope performance is benchmarked on the actual host without affecting collector/live-write latency.

**Delivery bundle:** `NIFTY_BACKTEST_PHASE_03_*.zip`


### 5.4 Phase 4 — Reverse Opportunity Discovery, Walk-Forward Validation and Calibrated Probability

**Objective:** Find repeatable pre-entry conditions from executable historical opportunities without leaking future outcomes into the strategy.

**Dependency:** Phases 1–3 and a qualified historical dataset snapshot.

**Features delivered**

- Executable next-bar opportunity labels using the same costs, targets, stops and path policy as replay.
- MFE, MAE, time-to-exit, ambiguity and net outcome evidence.
- Pre-entry feature association ranking that does not claim causality.
- Expanding chronological walk-forward splits with purge and embargo.
- Out-of-fold probability calibration, Brier score, log loss, ROC AUC and reliability bins.
- Checksummed model artifacts with immutable feature lists and data/code identities.
- Model and feature evidence tables; no automatic strategy promotion.
- Foundation for later multiple-testing, stability, PBO and deflated-Sharpe gates.

**Release criteria**

- Every label has decision_ts < entry_ts ≤ exit_ts and uses observed future bars only for the label.
- No forward-return, future high/low, final-day or outcome column enters the model feature matrix.
- Walk-forward splits are chronological and respect declared label horizon through purge/embargo.
- Displayed probabilities are derived from strictly out-of-fold predictions and include sample counts/reliability bins.
- An untouched final holdout is reserved before strategy selection in the production workflow.
- Candidate rules remain research artefacts until replayed as frozen strategy versions under Phase 3.

**Delivery bundle:** `NIFTY_BACKTEST_PHASE_04_*.zip`


### 5.5 Phase 5 — Buying-Only Options Research, Historical/Online Parity and Analyst Research Packs

**Objective:** Extend the governed backtesting platform to actual option premiums and make results portable to the later live/reporting architecture.

**Dependency:** Phases 1–4; actual historical option contract and premium data must pass qualification.

**Features delivered**

- Point-in-time selection of actual active CE/PE contracts by expiry, strike, moneyness and lot size.
- Buying-only option simulation using observed premium OHLC rather than synthetic option pricing.
- Premium target, premium stop, lot sizing, expiry/time exits and option transaction costs.
- Black–Scholes diagnostic price, delta, gamma, theta, vega, rho and implied-volatility inversion.
- Correctness-first online replay oracle and batch/online feature parity evidence.
- Checksummed research ZIP packs with summary Markdown, source data, manifests and analyst-response schema.
- Unified CLI demonstrations for qualification, target solving, replay, discovery, options, parity and packs.
- Database entities for option results, parity evidence, packs and non-authoritative analyst responses.

**Release criteria**

- Option backtests use actual option premium bars and a contract that was active/known at decision time.
- Order quantity is an integer multiple of the effective lot size and fits the cash ticket including charges.
- Greeks/IV calculations pass golden vectors and are clearly diagnostic rather than substitutes for market premiums.
- Stale or absent option chain/Greeks/contract data fails closed and is visible in result quality.
- Batch and incremental replay features match within declared tolerance for all parity-certified features.
- Every research ZIP verifies its own file checksums and contains no unsafe archive paths.
- No broker order placement is added; the output is ready for later paper/shadow integration only.

**Delivery bundle:** `NIFTY_BACKTEST_PHASE_05_*.zip`

## 6. Work-package decomposition for parallel developers

Each phase is divided by bounded ownership. Several work packages may proceed in parallel after the phase contract is frozen, but integration occurs through one phase owner.

| Work package | Primary ownership | Files/domains | May run in parallel with | Merge gate |
|---|---|---|---|---|
| P1-WP1 Contracts/calendar | Platform architect | `contracts.py`, `calendar/`, JSON Schemas | P1-WP2 | Session/expiry vectors |
| P1-WP2 Data qualification | Data engineer | `data/manifest.py`, `csv_profiler.py`, PostgreSQL adapters | P1-WP1 | Qualification report |
| P2-WP1 Economics | Quant/platform engineer | `costs/`, fee vectors | P2-WP2 | Contract-note/golden parity |
| P2-WP2 Feature/strategy SDK | Quant engineer | `features/`, `strategy/`, reference strategies | P2-WP1 | Prefix parity and manifest tests |
| P2-WP3 Simulator | Backtest engineer | `simulation/` | After P2-WP1 interfaces freeze | Event and accounting tests |
| P3-WP1 Run orchestration | Platform engineer | `orchestration/` | P3-WP2 | Restart/idempotency |
| P3-WP2 Persistence/metrics | DB + analytics engineer | migration 003, `reporting/`, `evaluation/` | P3-WP1 | Reconciliation and publication guard |
| P4-WP1 Labels/discovery | Quant research engineer | `discovery/labels.py`, patterns | P4-WP2 | Leakage audit |
| P4-WP2 Validation/calibration | ML/statistics engineer | walk-forward, calibration, evidence | P4-WP1 | OOF/holdout evidence |
| P5-WP1 Options | Derivatives quant | contracts, premiums, Greeks, option simulator | P5-WP2 | Actual-premium/freshness tests |
| P5-WP2 Parity/report packs | Live integration + reporting engineer | `live/parity.py`, pack/response contracts | P5-WP1 | Parity and archive verification |

### 6.1 Git and integration discipline

- Use `DEV_PM_CODE` as the integration branch. Short-lived work branches/worktrees may be created for individual work packages and merged through review.
- One named owner controls each shared contract and migration file.
- A schema or contract change requires regenerated schemas/vectors and consumer tests.
- No agent edits a shared calculation in Go, Python and TypeScript independently. The canonical implementation and golden vectors govern retained ports.
- Every agent produces a phase completion record with commands, evidence and rollback.

## 7. Integration sequence against the existing code

```mermaid
flowchart TD
    A[Inspect actual target repository] --> B[Create baseline and branch]
    B --> C[Apply phase overlay to platform/nifty_stratlab]
    C --> D[Adapt legacy code through narrow interfaces]
    D --> E[Run disposable DB migration tests]
    E --> F[Run phase + affected legacy tests]
    F --> G{All release criteria evidenced?}
    G -- No --> H[Fix or preserve partial output; do not publish]
    H --> F
    G -- Yes --> I[Commit and merge to DEV_PM_CODE]
    I --> J[Begin next phase]
```

### 7.1 Existing-code disposition

| Existing path | Planned treatment |
|---|---|
| `backtesting/internal/backtest/history.go` | Retain useful data/range orchestration, then route execution through canonical run/shard contracts |
| `archive_runner.go` | Reuse ingestion patterns after Phase 1 qualification gate |
| `strategy_backtest.go` | Reconcile next-bar and stop-first semantics with Phase 2 |
| `a02.go` | Quarantine same-day look-ahead exit logic |
| `options_backtest.go` | Refactor in Phase 5 around point-in-time contracts and actual premiums |
| `nifty_backtesting_worker.py` | Split monolith into adapters/orchestration; remove dynamic fee fallback and invalid publication |
| `backtest_transaction_charges.go` | Replace with golden-vector-compatible wrapper/port |
| `indicator_strategy_registry.yml` | Convert strategy definitions to immutable manifests |
| `nse_app.backtest_*` families | Compatibility/read-only period, then views or archival after reconciliation |
| TypeScript routes | Consume versioned canonical results and packs; no business calculation duplication |

## 8. Testing strategy

### 8.1 Automated layers

1. Unit tests for calculations, validators and state transitions.
2. Golden tests for fees, session/expiry and Greeks across languages.
3. Property/invariant tests for OHLC, accounting, target ticks and chronological splits.
4. Integration tests against a disposable PostgreSQL database.
5. Replay tests against a qualified, checksum-pinned historical slice.
6. Kill/restart and lease-expiry recovery tests.
7. Legacy reconciliation tests for rows, trades, metrics and dashboards.
8. Full-scope performance and collector-latency tests on the actual host.

### 8.2 Mandatory invariants

- `available_at` cannot precede the source event.
- A strategy cannot observe a feature before its availability time.
- Entry from a completed-bar signal cannot occur before the next executable event.
- `net_pnl = gross_pnl - total_cost`.
- `gross_equity = cash + market_value` and net liquidation does not exceed gross equity.
- A run cannot publish unless all expected shards complete and mandatory validation passes.
- Historical universe and contract membership are effective-dated.
- Model calibration uses out-of-fold chronological predictions.

## 9. Success measures by programme level

| Level | Success measure |
|---|---|
| Correctness | No known look-ahead, survivorship, cross-symbol indicator or fee inconsistency |
| Reproducibility | Same run identity produces identical checksums under pinned inputs |
| Recovery | Interrupted work resumes from the last durable shard/checkpoint |
| Financial fidelity | Charges reconcile to approved contract-note vectors and net targets use valid ticks |
| Research validity | Walk-forward/holdout evidence, calibration and trial history are retained |
| Operational safety | Failed quality/validation/freshness gates fail closed and cannot publish |
| Extensibility | New strategy requires manifest + plug-in + tests, not engine rewrites |
| Integration | Historical and incremental replay produce parity-certified features/signals |

## 10. Code delivery structure

Each phase ZIP contains:

- `overlay/platform/nifty_stratlab/` — phase-specific code delta;
- `CODEX_PROMPT.md` — full integration and test execution contract;
- `LOW_CONTEXT_TASK.md` — concise task for low-context coding agents;
- `RUN_CODEX.sh/.ps1` and `RUN_LOW_CONTEXT_AGENT.sh/.ps1`;
- `APPLY_OVERLAY.py/.sh/.ps1` with backup and dry-run;
- `VERIFY_PHASE.sh/.ps1`;
- `PHASE_PLAN.md`, `INTEGRATION_MAP.md`, `ACCEPTANCE_CRITERIA.md` and `SOURCE_BASIS.md`;
- `MANIFEST.json` with file hashes.

An integrated reference ZIP contains the cumulative package and all tests.

## 11. Verification completed for this delivery

- Python source compiled successfully.
- 22 automated tests passed.
- Five phase-specific smoke tests passed.
- The five overlays were applied sequentially to a clean mock Git repository.
- Each phase verifier passed after cumulative installation.
- The final cumulative test suite passed in the mock repository.
- CLI demonstrations completed for equity replay, deterministic run planning, discovery/calibration, options, parity, research packs and the ₹500 net target solver.

These results validate the supplied reference code and packaging. They do not prove integration with the actual deployed repository, real PostgreSQL server or eight-plus gigabyte historical file estate.

## 12. Required target-environment validation

Before the implementation is described as deployed:

1. Confirm actual target repository paths and dependency topology.
2. Run Phase 1 against the real historical directories and publish the qualification report.
3. Profile the FII/DII workbook contents and publication timing.
4. Run all five migrations against a disposable PostgreSQL clone.
5. Reconcile fee vectors against actual broker contract notes and effective dates.
6. Reconcile canonical outputs against legacy backtests for pinned samples.
7. Benchmark full ten-year replay, memory, database load and collector latency.
8. Qualify actual option contract/premium coverage; current audited options history is much shorter than equity history.
9. Keep all order placement disabled until a separate paper/shadow/live programme is approved.

## 13. Immediate execution order

1. Assign the Phase 1 owner and run `NIFTY_BACKTEST_PHASE_01.../RUN_CODEX.sh <repo>`.
2. Review the generated data qualification evidence before opening Phase 2.
3. Reconcile Phase 2 costs against broker contract notes and freeze golden vectors.
4. Run one narrow end-to-end historical slice through Phase 3 before expanding to ten years.
5. Freeze an untouched holdout before Phase 4 discovery begins.
6. Begin Phase 5 historical options only after actual contract/premium history passes quality gates.

## Appendix A — Safety boundary

This delivery contains research/backtesting, parity and evidence-pack code. It does not connect to a broker order endpoint. Test-only option fee schedules and synthetic data are clearly labelled. The example equity schedule is a reference vector and must not be considered production-approved without contract-note reconciliation.
